<?php
	require_once("controller/handlerRecette.php");
	require_once("controller/handlerUser.php");

	session_start();
	$action = "Accueil";
	$userController = false;

	if (isset($_GET["action"]))
	{
		if(in_array($_GET["action"],get_class_methods("handlerUser"))){
			$action = $_GET["action"];
			$userController = true;
		}
		else if(in_array($_GET["action"],get_class_methods("handlerRecette"))){
			$action = $_GET["action"];
			$userController = false;
		}
		
	}
	if (isset($_POST["action"]))
	{
		if(in_array($_POST["action"],get_class_methods("handlerUser"))){
		$action = $_POST["action"];
		$userController = true;
		}
		else if(in_array($_POST["action"],get_class_methods("handlerRecette"))){
		$action = $_POST["action"];
		$userController = false;
		}
	};

	if(isset($_GET["id"]) && $action == "ViewRecette"){
		if($userController){
			handlerUser::$action($_GET["id"]);
		}else{
			handlerRecette::$action($_GET["id"]);
		}
	}else{
		if($userController){
			handlerUser::$action();
		}else{
			handlerRecette::$action();
		}
	}
	
?>