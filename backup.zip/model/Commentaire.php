<?php
require_once("config/Connexion.php");
Connexion::connect();

class Commentaire {
  
    private $CommentaireID;
    private $Text;
    private $RecetteID;
    private $UserID;
    private $Note;
    private $Date;
    private $Statut;

    //getters and setters
    public function getCommentaireID() {
        return $this->CommentaireID;
    }

    public function getText() {
        return $this->Text;
    }

    public function getRecetteID() {
        return $this->RecetteID;
    }

    public function getUserID() {
        return $this->UserID;
    }

    public function getNote() {
        return $this->Note;
    }

    public function getDate() {
        return $this->Date;
    }

    public function getStatut() {
        return $this->Statut;
    }

    public function setCommentaireID($CommentaireID) {
        $this->CommentaireID = $CommentaireID;
    }

    public function setText($Text) {
        $this->Text = $Text;
    }

    public function setRecetteID($RecetteID) {
        $this->RecetteID = $RecetteID;
    }

    public function setUserID($UserID) {
        $this->UserID = $UserID;
    }

    public function setNote($Note) {
        $this->Note = $Note;
    }

    public function setDate($Date) {
        $this->Date = $Date;
    }

    public function setStatut($Statut) {
        $this->Statut = $Statut;
    }





    public static function checkInsult($text){
        $params = array(
            'text' => $text,
            'lang' => 'fr',
            'opt_countries' => 'us,gb,fr',
            'mode' => 'standard',
            'api_user' => '1117381528',
            'api_secret' => 'cYJpZUcVSut3yC7YGngD',
        );
        $ch = curl_init('https://api.sightengine.com/1.0/text/check.json');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        $response = curl_exec($ch);
        curl_close($ch);
        $output = json_decode($response, true);
        if(isset($output["profanity"]["matches"])){
            return true;
        }
        else{
            return false;
        }
    }

    public static function getAllCommentaires($recetteID){
        $sql = "SELECT * FROM commentaires WHERE RecetteID = :recetteID ORDER BY Date DESC";
        $req = Connexion::pdo()->prepare($sql);
        $req->execute(array(
            'recetteID' => $recetteID
        ));
        $commentaires = $req->fetchAll(PDO::FETCH_CLASS, 'Commentaire');
        return $commentaires;
    }

    public static function getCommentaireByStatut($recetteID, $statut){
        $sql = "SELECT * FROM commentaires WHERE RecetteID = :recetteID AND Statut = :statut";
        $req = Connexion::pdo()->prepare($sql);
        $req->execute(array(
            'recetteID' => $recetteID,
            'statut' => $statut
        ));
        $commentaires = $req->fetchAll(PDO::FETCH_CLASS, 'Commentaire');
        return $commentaires;
    }

    public static function addCommentaire($recetteID, $userID, $text, $note){
        $sql = "INSERT INTO commentaires (RecetteID, UserID, Text, Note, Statut, Date) VALUES (:recetteID, :userID, :text, :note, :statut, NOW());";
        $req = Connexion::pdo()->prepare($sql);
        if($note>5){
            $note = 5;
        }
        if($note<0){
            $note = 0;
        }
        $statut = 0;
        if(Utils::checkInsulte($text)){
            $text = "Ce commentaire a été signalé comme insultant.";
        }
        if($req->execute(array(
            'recetteID' => $recetteID,
            'userID' => $userID,
            'text' => $text,
            'note' => $note,
            'statut' => 0
        ))){
            return true;
        }
        else{
            return false;
        }
    }

    public static function deleteCommentaire($commentaireID){
        $sql = "DELETE FROM commentaires WHERE CommentaireID = :commentaireID";
        $req = Connexion::pdo()->prepare($sql);
        if($req->execute(array(
            'commentaireID' => $commentaireID
        ))){
            return true;
        }
        else{
            return false;
        }
    }

    public static function getCommentaireByUserRecetteID($userID){
        $commentaires = array();
        $recettes = Recette::getRecetteByUserID($userID);
        foreach($recettes as $recette){
            $commentaires = array_merge($commentaires,Commentaire::getAllCommentaires($recette->getRecetteID()));
        }
        if(!$commentaires){
            $commentaires = array();
        }
        return $commentaires;
    }

    public static function getCommentaireByID($commentaireID){
        $sql = "SELECT * FROM commentaires WHERE CommentaireID = :commentaireID";
        $req = Connexion::pdo()->prepare($sql);
        $req->execute(array(
            'commentaireID' => $commentaireID
        ));
        $commentaire = $req->fetchObject('Commentaire');
        return $commentaire;
    }

    public function updateStatut($statut){
        $sql = "UPDATE commentaires SET Statut = :statut WHERE CommentaireID = :commentaireID";
        $req = Connexion::pdo()->prepare($sql);
        if($req->execute(array(
            'statut' => $statut,
            'commentaireID' => $this->CommentaireID
        ))){
            return true;
        }
        else{
            return false;
        }
    }

    public function delete(){
        $sql = "DELETE FROM commentaires WHERE CommentaireID = :commentaireID";
        $req = Connexion::pdo()->prepare($sql);
        if($req->execute(array(
            'commentaireID' => $this->CommentaireID
        ))){
            return true;
        }
        else{
            return false;
        }
    }
}

?>