<?php
require_once("config/Connexion.php");
Connexion::connect();

class Ingredient {

    private $IngredientID;
    private $RecetteID;
    private $NomIngredient;
    private $QuantiteIngredient;
    private $UniteIngredient;
    
    //getters and setters
    public function getIngredientID() {
        return $this->IngredientID;
    }
    public function getRecetteID() {
        return $this->RecetteID;
    }
    public function getNomIngredient() {
        return $this->NomIngredient;
    }
    public function getQuantiteIngredient() {
        return $this->QuantiteIngredient;
    }
    public function getUniteIngredient() {
        return $this->UniteIngredient;
    }
    
    public function setIngredientID($IngredientID) {
        $this->IngredientID = $IngredientID;
    }
    public function setRecetteID($RecetteID) {
        $this->RecetteID = $RecetteID;
    }
    public function setNomIngredient($NomIngredient) {
        $this->NomIngredient = $NomIngredient;
    }
    public function setQuantiteIngredient($QuantiteIngredient) {
        $this->QuantiteIngredient = $QuantiteIngredient;
    }
    public function setUniteIngredient($UniteIngredient) {
        $this->UniteIngredient = $UniteIngredient;
    }



    public static function addIngredient($RecetteID, $Nom, $Quantite, $Unite) { 
        $query = "INSERT INTO ingredient (RecetteID, NomIngredient, QuantiteIngredient,UniteIngredient) VALUES (:tag_recetteID, :tag_nom , :tag_quantite, :tag_unite)";
        $req_prep = Connexion::pdo()->prepare($query);
        $values = array(
            "tag_recetteID" => $RecetteID,
            "tag_nom" => $Nom,
            "tag_quantite" => $Quantite,
            "tag_unite" => $Unite
        );
        if($req_prep->execute($values)) {
            return true;
        }
        return false;
    }

    public static function getIngredientsByRecetteID($RecetteID) {
        $query = "SELECT * FROM ingredient WHERE RecetteID = :tag_recetteID";
        $req_prep = Connexion::pdo()->prepare($query);
        $values = array(
            "tag_recetteID" => $RecetteID
        );
        $req_prep->execute($values);
        $req_prep->setFetchMode(PDO::FETCH_CLASS, "Ingredient");
        $result = $req_prep->fetchAll();
        return $result;
    }

    public static function editIngredient($IngredientID, $Nom, $Quantite, $Unite) {
        $query = "UPDATE ingredient SET NomIngredient = :tag_nom, QuantiteIngredient = :tag_quantite, UniteIngredient = :tag_unite WHERE IngredientID = :tag_ingredientID";
        $req_prep = Connexion::pdo()->prepare($query);
        $values = array(
            "tag_ingredientID" => $IngredientID,
            "tag_nom" => $Nom,
            "tag_quantite" => $Quantite,
            "tag_unite" => $Unite
        );
        if($req_prep->execute($values)) {
            return true;
        }
        return false;
    }
    public function delete() {
        $query = "DELETE FROM ingredient WHERE IngredientID = :tag_ingredientID";
        $req_prep = Connexion::pdo()->prepare($query);
        $values = array(
            "tag_ingredientID" => $this->IngredientID
        );
        if($req_prep->execute($values)) {
            return true;
        }
        return false;
    }

}
?>