<?php
require_once("model/Insulte.php");
class Utils
{
    public static function genString($length = 5)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    public static function get_time_ago_string($time_stamp, $divisor, $time_unit)
    {
        $time_difference = strtotime("now") - $time_stamp;
        $time_units      = floor($time_difference / $divisor);

        settype($time_units, 'string');

        if ($time_units === '0') {
            return "il y a moins d'une  " . $time_unit ;
        } elseif ($time_units === '1') {
            return 'Il y a 1 ' . $time_unit;
        } else {
            return 'Il y a '.$time_units . ' ' . $time_unit . 's';
        }
    }

    public static function get_time_ago($time_stamp)
    {
        $time_difference = strtotime('now') - $time_stamp;

        if ($time_difference >= 60 * 60 * 24 * 365.242199) {
        
            return Utils::get_time_ago_string($time_stamp, 60 * 60 * 24 * 365.242199, 'année');
        } elseif ($time_difference >= 60 * 60 * 24 * 30.4368499) {
            
            return Utils::get_time_ago_string($time_stamp, 60 * 60 * 24 * 30.4368499, 'mois');
        } elseif ($time_difference >= 60 * 60 * 24 * 7) {
           
            return Utils::get_time_ago_string($time_stamp, 60 * 60 * 24 * 7, 'semaine');
        } elseif ($time_difference >= 60 * 60 * 24) {
            
            return Utils::get_time_ago_string($time_stamp, 60 * 60 * 24, 'jour');
        } elseif ($time_difference >= 60 * 60) {
            
            return Utils::get_time_ago_string($time_stamp, 60 * 60, 'heure');
        } else {
            
            return Utils::get_time_ago_string($time_stamp, 60, 'minute');
        }
    }

    public static function checkInsulte($text){
        $words = explode(" ", $text);
        foreach($words as $word){
            if(in_array($word, Insulte::$insultes)){
                return true;
            }
        }
        if(in_array($text, Insulte::$insultes)){
            return true;
        }
        return false;
    }
}
?>