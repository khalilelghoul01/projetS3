<?php
	require_once("config/Connexion.php");
	Connexion::connect();
	Connexion::sqlConnect();

	class Utilisateur{
		private $UserID;
		private $Statut;
		private $Username;
		private $Bio = "none";
		private $Password;
		private $Email;
		private $Photo;
		private $Date;

		

		//Getter
		public function getUserID() {
			return $this->UserID;
		}
		public function getStatut() {
			return $this->Statut;
		}
		public function getUsername() {
			return $this->Username;
		}
		public function getBio() {
			if($this->Bio == "none"){
				return "";
			}
			return $this->Bio;
		}
		public function getPassword() {
			return $this->Password;
		}
		public function getEmail() {
			return $this->Email;
		}
		public function getPhoto() {
			if($this->Photo == "default" || $this->Photo == ""){
				return "images/users/default.png";
			}
			return $this->Photo;
		}
		public function getDate() {
			return $this->Date;
		}
		//Setter
		public function setUserID($IdU){
			$this->UserID=$IdU;
		}
		public function setStatut($S){
			$this->Statut=$S;
		}
		public function setUsername($P){
			$this->Username=$P;
		}
		public function setBio($DecU){
			$this->Bio=$DecU;
		}
		public function setPassword($Mdp){
			$this->Password=$Mdp;
		}
		public function setEmail($M){
			$this->Email=$M;
		}
		public function setPhoto($adressPhotoProfil){
			$this->Photo=$adressPhotoProfil;
		}
		public function setDate($date){
			$this->Date=$date;
		}

		//METHODES
		public static function Nombreutilisateur(){
			$requete = "SELECT max(UserID) as id FROM `utilisateur`;";
			$con = Connexion::con();
			$resultat = mysqli_query($con,$requete);
			$ligne = mysqli_fetch_array($resultat);
			$id = intval($ligne['id'])+1;
			return $id;
		}
		public static function getUser($user){
			$requete = "SELECT * FROM `utilisateur` WHERE Email = :tag_user;";
			$req_prep = Connexion::pdo()->prepare($requete);
			$req_prep->execute(array(':tag_user' => $user));
			$req_prep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');
			$resultat = $req_prep->fetch();
			return $resultat;
		}

		public static function getUserById($id){
			$requete = "SELECT * FROM `utilisateur` WHERE UserID = :tag_user;";
			$req_prep = Connexion::pdo()->prepare($requete);
			$req_prep->execute(array(':tag_user' => $id));
			$req_prep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');
			$resultat = $req_prep->fetch();
			return $resultat;
		}

		public static function addutilisateur($P,$DecU,$Mdp,$M,$adressPhotoProfil="none"){
			if(utilisateur::checkUserExist($P,$M)){
				return false;
			}
			$requetePreparee = "INSERT INTO utilisateur (`Statut`, `Username`, `Bio`, `Password`, `Email`, `Photo`, `Date`) VALUES(:tag_Statut, :tag_UserName, :tag_Bio,:tag_MotDePasse,:tag_Email,:tag_AdrrPhotoProfil,NOW());";
			$req_prep = Connexion::pdo()->prepare($requetePreparee);
			$con = Connexion::con();
			$valeurs = array(
				"tag_Statut" =>"0",
				"tag_UserName" =>$P,
				"tag_Bio" =>$DecU,
				"tag_MotDePasse" =>hash('ripemd160',mysqli_real_escape_string($con,htmlspecialchars(stripslashes($Mdp)))),
				"tag_Email" =>$M,
				"tag_AdrrPhotoProfil" =>$adressPhotoProfil,
			);
			

			try{
				$req_prep->execute($valeurs);
				return true;
			} catch (PDOException $e){
				echo "erreur : ".$e->getMessage()."<br>";
				return false;
			}
		}


		public static function checkUser($username,$password){
			$queryUsername = "SELECT count(*) as checkUser FROM `utilisateur` WHERE Email = :tag_user AND Password = :tag_passwd;";
			$req_prep = Connexion::pdo()->prepare($queryUsername);
			$con = Connexion::con();
			$valeurs = array(
				"tag_user" =>mysqli_real_escape_string($con,htmlspecialchars(stripslashes($username))),
				"tag_passwd" =>hash('ripemd160',mysqli_real_escape_string($con,htmlspecialchars(stripslashes($password))))
			);
			$req_prep->execute($valeurs);
			$resultat = $req_prep->fetch(PDO::FETCH_ASSOC);
			if($resultat['checkUser'] >= 1){
				return true;
			}
			return false;
		}
		public static function checkUserExist($username,$email){
			$query = "SELECT count(*) as checkUser FROM `utilisateur` WHERE Username = :tag_username OR Email = :tag_email ;";
			$req_prep = Connexion::pdo()->prepare($query);
			$con = Connexion::con();
			$valeurs = array(
				"tag_username" =>mysqli_real_escape_string($con,htmlspecialchars(stripslashes($username))),
				"tag_email" =>mysqli_real_escape_string($con,htmlspecialchars(stripslashes($email)))
			);
			$req_prep->execute($valeurs);
			$resultat = $req_prep->fetch(PDO::FETCH_ASSOC);
			if($resultat['checkUser'] >= 1){
				return true;
			}
			return false;	
		}

		public static function checkEmailExist($email,$username){
			$query = "SELECT count(*) as checkUser , Username FROM `utilisateur` WHERE  Email = :tag_email ;";
			$req_prep = Connexion::pdo()->prepare($query);
			$con = Connexion::con();
			$valeurs = array(
				"tag_email" =>mysqli_real_escape_string($con,htmlspecialchars(stripslashes($email)))
			);
			$req_prep->execute($valeurs);
			$resultat = $req_prep->fetch(PDO::FETCH_ASSOC);
			if($resultat['Username'] == $username){
				return false;
			}
			if(intval($resultat['checkUser']) >= 1){
				return true;
			}
			return false;	
		}


		public static function getImageFromUser($user){
			$query = "SELECT * FROM `utilisateur` WHERE Username = :tag_username OR Email = :tag_username;";
			$req_prep = Connexion::pdo()->prepare($query);
			$con = Connexion::con();
			$valeurs = array(
				"tag_username" =>mysqli_real_escape_string($con,htmlspecialchars(stripslashes($user)))
			);
			$req_prep->execute($valeurs);
			$req_prep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');
			$resultat = $req_prep->fetch();
			$photo = $resultat->getPhoto();
			if($photo == "default" || $photo == ""){
				return "images/users/default.png";
			}
			return $photo;
		}

		public static function getUsersByQuery($query){
			$requete = "SELECT * FROM `utilisateur` WHERE Username LIKE '%$query%' OR Email LIKE '%$query%';";
			$req_prep = Connexion::pdo()->prepare($requete);
			$req_prep->execute();
			$req_prep->setFetchMode(PDO::FETCH_CLASS, 'Utilisateur');
			$resultat = $req_prep->fetchAll();
			return $resultat;
		}

		public function delete(){
			$requete = "DELETE FROM `utilisateur` WHERE UserID = :tag_id;";
			$req_prep = Connexion::pdo()->prepare($requete);
			$valeurs = array(
				"tag_id" =>$this->getUserID()
			);
			$req_prep->execute($valeurs);
		}

		public static function editUser($id,$username,$bio,$email,$password,$photo){
			$requete = "UPDATE `utilisateur` SET Username = :tag_username, Bio = :tag_bio, Email = :tag_email, Password = :tag_password, Photo = :tag_photo WHERE UserID = :tag_id;";
			$req_prep = Connexion::pdo()->prepare($requete);
			$con = Connexion::con();
			$valeurs = array(
				"tag_username" =>htmlentities($username),
				"tag_bio" =>htmlentities($bio),
				"tag_email" =>htmlentities($email),
				"tag_password" =>hash('ripemd160',mysqli_real_escape_string($con,htmlspecialchars(stripslashes($password)))),
				"tag_photo" =>htmlentities($photo),
				"tag_id" =>htmlentities($id)
			);
			if($req_prep->execute($valeurs)){
				return true;
			}
			return false;
		}

	}

?>