<?php
require_once("config/Connexion.php");
Connexion::connect();
class Categorie
{
    private $CategorieID;
    private $NomCategorie;

    //Getter
    public function getCategorieID()
    {
        return $this->CategorieID;
    }
    public function getNomCategorie()
    {
        return $this->NomCategorie;
    }

    //Setter

    public function setCategorieID($IdC)
    {
        $this->CategorieID = $IdC;
    }

    public function setNomCategorie($NomC)
    {
        $this->NomCategorie = $NomC;
    }


    public static function getAllCategories()
    {
        $requete = "SELECT * FROM categorie;";
        $reponse = Connexion::pdo()->query($requete);
        $reponse -> setFetchMode(PDO::FETCH_CLASS,'categorie');
        $tab = $reponse->fetchAll();
        return $tab;
    }

    public static function getCategorieByID($id)
    {
        $requete = "SELECT * FROM categorie WHERE CategorieID = $id;";
        $reponse = Connexion::pdo()->query($requete);
        $reponse -> setFetchMode(PDO::FETCH_CLASS,'categorie');
        $tab = $reponse->fetchAll();
        if(count($tab)==0){
            return null;
        }
        return $tab[0];
    }
}
