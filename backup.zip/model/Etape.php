<?php
require_once("config/Connexion.php");
Connexion::connect();

class Etape {

    private $EtapeID;
    private $RecetteID;
    private $Text;
    private $Ordre;
    
    //getters and setters
    public function getEtapeID() {
        return $this->EtapeID;
    }
    
    public function getRecetteID() {
        return $this->RecetteID;
    }
    
    public function getText() {
        return $this->Text;
    }
    
    public function getOrdre() {
        return $this->Ordre;
    }
    
    public function setEtapeID($EtapeID) {
        $this->EtapeID = $EtapeID;
    }
    
    public function setRecetteID($RecetteID) {
        $this->RecetteID = $RecetteID;
    }
    
    public function setText($Text) {
        $this->Text = $Text;
    }
    
    public function setOrdre($Ordre) {
        $this->Ordre = $Ordre;
    }
    

    public static function addEtape($RecetteID, $Text, $Ordre) {
        $query = "INSERT INTO etape (RecetteID, Text, Ordre) VALUES (:tag_recetteID, :tag_text , :tag_ordre)";
        $req_prep = Connexion::pdo()->prepare($query);
        $values = array(
            "tag_recetteID" => $RecetteID,
            "tag_text" => $Text,
            "tag_ordre" => $Ordre
        );
        if($req_prep->execute($values)) {
            return true;
        }
        return false;
    }

    public static function getEtapeByRecetteID($RecetteID) {
        $query = "SELECT * FROM etape WHERE RecetteID = :tag_recetteID ORDER BY Ordre";
        $req_prep = Connexion::pdo()->prepare($query);
        $values = array(
            "tag_recetteID" => $RecetteID
        );
        $req_prep->execute($values);
        $req_prep->setFetchMode(PDO::FETCH_CLASS, "Etape");
        $tab_etape = $req_prep->fetchAll();
        return $tab_etape;
    }

    public static function editEtape($EtapeID, $Text, $Ordre) {
        $query = "UPDATE etape SET Text = :tag_text, Ordre = :tag_ordre WHERE EtapeID = :tag_etapeID";
        $req_prep = Connexion::pdo()->prepare($query);
        $values = array(
            "tag_etapeID" => $EtapeID,
            "tag_text" => $Text,
            "tag_ordre" => $Ordre
        );
        if($req_prep->execute($values)) {
            return true;
        }
        return false;
    }

    public function delete() {
        $query = "DELETE FROM etape WHERE EtapeID = :tag_etapeID";
        $req_prep = Connexion::pdo()->prepare($query);
        $values = array(
            "tag_etapeID" => $this->EtapeID
        );
        if($req_prep->execute($values)) {
            return true;
        }
        return false;
    }

}
?>