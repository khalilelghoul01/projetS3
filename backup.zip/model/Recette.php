<?php
	require_once("config/Connexion.php");
	Connexion::connect();

	class Recette{
		private $RecetteID;
		private $Titre;
		private $UserID;
		private $Etapes;
		private $Description;
		private $Thumbnail;
		private $Duree;
		private $Niveau_Difficulte;
		private $Ingredients;
		private $NB_Personnes;
		private $Categorie;
		private $Date;
		private $Note;

		//Getter
		public function getRecetteID() {
			return $this->RecetteID;
		}
		public function getTitre() {
			return $this->Titre;
		}
		public function getUserID() {
			return $this->UserID;
		}
		public function getThumbnail() {
			return $this->Thumbnail;
		}
		public function getDuree() {
			return $this->Duree;
		}
		public function getNiveau_Difficulte() {
			return $this->Niveau_Difficulte;
		}
		public function getIngredients() {
			return $this->Ingredients;
		}
		public function getNB_Personnes() {
			return $this->NB_Personnes;
		}
		public function getCategorie() {
			return $this->Categorie;
		}
		public function getDate() {
			return $this->Date;
		}
		public function getNote() {
			return $this->Note;
		}
		public function getDescription() {
			return $this->Description;
		}
		//Setter
		public function setRecetteID($IdR){
			$this->RecetteID=$IdR;
		}
		public function setTitre($NomR){
			$this->Titre=$NomR;
		}
		public function setUserID($AuteurR){
			$this->UserID=$AuteurR;
		}
		public function setEtapes($DecR){
			$this->Etapes=$DecR;
		}
		public function setThumbnail($AdrPhoto){
			$this->Thumbnail=$AdrPhoto;
		}
		public function setDuree($TempsPrepaMin){
			$this->Duree=$TempsPrepaMin;
		}
		public function setNiveau_Difficulte($NvDifficulte){
			$this->Niveau_Difficulte=$NvDifficulte;
		}
		public function setIngredients($Ingredient){
			$this->Ingredients=$Ingredient;
		}
		public function setNB_Personnes($NbPersonne){
			$this->NB_Personnes=$NbPersonne;
		}
		public function setCategorie($Categorie){
			$this->Categorie=$Categorie;
		}
		public function setDate($Date){
			$this->Date=$Date;
		}
		public function setNote($Note){
			$this->Note=$Note;
		}
		public function setDescription($Description){
			$this->Description=$Description;
		}
		//Methode
		public static function NombreRecette(){
			$requete = "SELECT max(RecetteID) as id FROM `recette`;";
			$con = Connexion::con();
			$resultat = mysqli_query($con,$requete);
			$ligne = mysqli_fetch_array($resultat);
			$id = intval($ligne['id'])+1;
			return $id;
		}

		public static function getAllRecettes(){
			$requete = "SELECT * FROM recette ORDER BY Date DESC;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}
		public static function getRecetteByUserID($id){
			$requete = "SELECT * FROM recette WHERE UserID  = $id ORDER BY Date DESC;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}
		public static function getRecette($id){
			$requete = "SELECT * FROM recette WHERE RecetteID  = $id;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			if(count($tab)==0){
				return null;
			}
			return $tab[0];
		}

		public static function getRecetteByCategorie($categorie){
			$requete = "SELECT * FROM recette WHERE Categorie = '$categorie' ORDER BY Date DESC;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}

		public static function getRecetteByAuteur($auteur){
			$requete = "SELECT * FROM recette WHERE Auteur = '$auteur' ORDER BY Date DESC;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}

		public static function getRecetteByNom($nom){
			$requete = "SELECT * FROM recette WHERE Titre = '$nom' ORDER BY Date DESC;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}

		public static function getRecetteByNiveau($niveau){
			$requete = "SELECT * FROM recette WHERE Niveau_Difficulte = '$niveau';";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}

		public static function addRecette($titre,$userId,$description,$image,$duree,$difficulte,$nbpersonnes,$categories){
			$requete = "INSERT INTO recette (`Titre`, `UserID`,`Description`, `Thumbnail`, `Duree`, `Niveau_Difficulte`, `NB_Personnes`, `Categorie`, `Date`, `Note`) VALUES (:tag_title,:tag_user_id,:tag_description,:tag_image,:tag_duree,:tag_difficulte,:tag_nbpersonnes,:tag_categories,NOW(),'0');";
			$req_prep = Connexion::pdo()->prepare($requete);
			$values = array(
				':tag_title' => $titre,
				':tag_user_id' => $userId,
				':tag_description' => $description,
				':tag_image' => $image,
				':tag_duree' => $duree,
				':tag_difficulte' => $difficulte,
				':tag_nbpersonnes' => $nbpersonnes,
				':tag_categories' => $categories
			);
			if($req_prep->execute($values)){
				return true;
			}
			return false;
		}

		public static function getRecetteOrderByNote(){
			//limite la requete à 10 résultats
			$requete = "SELECT * FROM recette ORDER BY Note DESC LIMIT 10;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}

		public static function getNbRecetteByUserID($id){
			$requete = "SELECT count(*) as nb FROM recette WHERE UserID = $id;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab[0]->nb;
		}

		public static function getRecettesByQuery($query){
			$requete = "SELECT * FROM recette WHERE Titre LIKE '%$query%' OR Description LIKE '%$query%' OR Categorie LIKE '%$query%' OR UserID LIKE '%$query%' OR Niveau_Difficulte LIKE '%$query%' OR NB_Personnes LIKE '%$query%' OR Duree LIKE '%$query%' ORDER BY Date DESC;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}

		public static function getTotalRecette(){
			$requete = "SELECT count(*) as nb FROM recette;";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_ASSOC);
			$tab = $reponse->fetch();
			return $tab['nb'];
		} 

		public static function getRecetteByPage($page,$nb){
			$requete = "SELECT * FROM recette ORDER BY Date DESC LIMIT ".(($page-1)*$nb).",".$nb.";";
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}

		public static function getRecetteByPageByUser($page,$nb,$userId){
			if($nb == 0){
				$requete = "SELECT * FROM recette WHERE UserID = $userId ORDER BY Date DESC;";
			}else{
				$requete = "SELECT * FROM recette WHERE UserID = $userId ORDER BY Date DESC LIMIT ".(($page-1)*$nb).",".$nb.";";
			}
			$reponse = Connexion::pdo()->query($requete);
			$reponse -> setFetchMode(PDO::FETCH_CLASS,'Recette');
			$tab = $reponse->fetchAll();
			return $tab;
		}

		public function delete(){
			$requete = "DELETE FROM recette WHERE RecetteID = :id;";
			$req_prep = Connexion::pdo()->prepare($requete);
			$values = array(
				':id' => $this->RecetteID
			);
			if($req_prep->execute($values)){
				return true;
			}
			return false;
		}

		public static function editRecette($id,$titre,$description,$image,$duree,$difficulte,$nbpersonnes,$categories){
			$requete = "UPDATE recette SET Titre = :tag_title, Description = :tag_description, Thumbnail = :tag_image, Duree = :tag_duree, Niveau_Difficulte = :tag_difficulte, NB_Personnes = :tag_nbpersonnes, Categorie = :tag_categories WHERE RecetteID = :id;";
			$req_prep = Connexion::pdo()->prepare($requete);
			$values = array(
				':tag_title' => $titre,
				':tag_description' => $description,
				':tag_image' => $image,
				':tag_duree' => $duree,
				':tag_difficulte' => $difficulte,
				':tag_nbpersonnes' => $nbpersonnes,
				':tag_categories' => $categories,
				':id' => $id
			);
			if($req_prep->execute($values)){
				return true;
			}
			return false;
		}
		

	}
?>