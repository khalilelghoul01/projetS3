<?php
	require_once("model/Recette.php");
	require_once("model/Utilisateur.php");
	require_once("model/Commentaire.php");
	require_once("model/Categorie.php");
	require_once("model/Utils.php");
	require_once("config/Connexion.php");
	Connexion::connect();
	class handlerUser{

		public static function Signup(){
						
			if(isset($_SESSION['username'])){
				header("Location: routeur.php?action=Accueil&warning=vous êtes déjà connecté");
			}
			include("view/signup.php");
		}

		public static function Login(){
			
			if(isset($_SESSION['username'])){
				header("Location: routeur.php?action=Accueil&warning=vous êtes déjà connecté");
			}
			include("view/login.php");
		}

		public static function Logout(){
			
			session_destroy();
			header("Location: routeur.php?action=Accueil&success=vous êtes déconnecté");
		}

		public static function CreateAccount(){
			
			if(isset($_SESSION['username'])){
				header("Location: routeur.php?action=Accueil&warning=vous êtes déjà connecté");
			}
			if(isset($_POST['envoyer'])){
				$email = $_POST['email'];
				$username = $_POST['username'];
				$password = $_POST['password'];
				$bio = $_POST['bio'] == "" ? "none" : $_POST['bio'];
				$target_dir = "images/users/".$username."/";
				$imageFileType = strtolower(pathinfo($_FILES["photo"]["name"],PATHINFO_EXTENSION));
				$target_file = $target_dir . basename($_FILES["photo"]["name"]) . Utils::genString() . ".$imageFileType";
				$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
				$check = getimagesize($_FILES["photo"]["tmp_name"]);
				$valid = $username!='' && $password!='' && $email!='' && $username != $email && strlen($password)>=8 && strlen($username)>=4;
				if($valid){
					if($check !== false) {
						mkdir($target_dir, 0777);
						$photo = $target_file;
						if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
						&& $imageFileType != "gif" ){
							header("Location: routeur.php?action=Signup&error=Désolé, seuls les fichiers JPG, JPEG, PNG et GIF sont autorisés");
						}
						if($_FILES["photo"]["size"] > 50000){
							header("Location: routeur.php?action=Signup&error=Désolé, votre fichier est trop volumineux");
						}
						if(file_exists($target_file)){
							header("Location: routeur.php?action=Signup&error=Désolé, le fichier existe déjà");
						}
						move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file);
					} else {
						$photo = "default";
						header("Location: routeur.php?action=Signup&error=Désolé, votre fichier n'a pas été téléchargé");
					}
				
					if(Utilisateur::addUtilisateur($username,$bio,$password,$email,$photo)){
						$_SESSION['username'] = $username;
						$_SESSION['email'] = $email;
						$user = Utilisateur::getUser($email);
						$_SESSION['id'] = $user->getUserID();
						$_SESSION['image'] = Utilisateur::getImageFromUser($username);
						header("Location: routeur.php?action=Accueil");
					}else{
						header('Location:  routeur.php?action=Signup&error=le compte existe déjà');
					}	
				}
				else{
					$error = "il faut que le mot de passe soit supérieur à 8 caractères, que le nom d'utilisateur soit supérieur à 4 caractères, que le nom d'utilisateur et l'email soient différents"; 
					header("Location:  routeur.php?action=Signup&error=$error");
				}
			}
		}
		public static function LoginAccount(){
			
			if(isset($_SESSION['username'])){
				header("Location: routeur.php?action=Accueil&warning=vous êtes déjà connecté");
			}
			if(isset($_POST['envoyer'])){
				$email = $_POST['username'];
				$password = $_POST['password'];
				if(Utilisateur::checkUser($email,$password)){
					$user = Utilisateur::getUser($email);
					echo "<pre>";
					print_r($user);
					echo "</pre>";
					$_SESSION['email'] = $user->getEmail();
					$_SESSION['id'] = $user->getUserID();
					$username = $user->getUsername();
					$_SESSION['username'] = $username;
					$_SESSION['image'] = Utilisateur::getImageFromUser($username);
					header("Location: routeur.php?action=Accueil&success=Vous êtes connecté");
				}else{
					header('Location:  routeur.php?action=Login&error=Mauvais identifiants');
				}
			}
		}

		public static function Profile(){
			if(isset($_GET['id'])){
				$tab = 1;
				$userId = $_GET['id'];
				$nbRecettesPerUser = Recette::getNbRecetteByUserID($userId);
				$user = Utilisateur::getUserById($userId);
				if(!$user){
					header("Location: routeur.php?action=Accueil&error=Cet utilisateur n'existe pas");
				}
				$username = $user->getUsername();
				$userRecette = Recette::getRecetteByUserID($userId);
				$userPhoto = $user->getPhoto();
				$bio = $user->getBio();
				include("view/profile.php");
			}else{
				if(isset($_SESSION['username'])){
					if(isset($_SESSION['image']) ){
						$image = $_SESSION['image'];
						if($image == null){
						$image = "images/users/default.png";
						}
					}
					$tab = 1;
					if(isset($_GET['tab'])){
						$tab = $_GET['tab'];
					}
					if(intval($tab) != 1){
						$tab = 2;
					}
					$userId = $_SESSION['id'];
					$nbRecettesPerUser = Recette::getNbRecetteByUserID($userId);
					$username = $_SESSION['username'];
					$email = $_SESSION['email'];
					$user = Utilisateur::getUser($email);
					$userRecette = Recette::getRecetteByUserID($userId);
					$userPhoto = $user->getPhoto();
					$bio = $user->getBio();
					include("view/profile.php");
				}else{
					header("Location: routeur.php?action=Accueil&warning=vous devez être connecté");
				}
			}
		}
		public static function EditProfile(){
			if(!isset($_SESSION['id']))
			{
				header("Location: routeur.php?action=Accueil&warning=vous devez être connecté");
			}
			$user = Utilisateur::getUser($_SESSION['email']);
			if(!$user)
			{
				header("Location: routeur.php?action=Accueil&error=Cet utilisateur n'existe pas");
			}
			$email = $user->getEmail();
			$bio = $user->getBio();
			$username = $user->getUsername();
			$oldPassword = $user->getPassword();
			$photo = $_SESSION['image'];
			if(!isset($_POST['envoyer'])){
				include("view/editProfile.php");
			}else{
				if(!isset($_POST['password']) || !isset($_POST['email']) || !isset($_POST['bio'])){
					header("Location: routeur.php?action=EditProfile&error=Vous devez remplir tous les champs");
				}else{
					if(Utilisateur::checkEmailExist($_POST['email'],$_SESSION['username'])){
						header("Location: routeur.php?action=EditProfile&error=Cet email existe déjà");
					}
					if(Utilisateur::editUser($_SESSION['id'],$_SESSION['username'],$_POST['bio'],$_POST['email'],$_POST['password'],$photo)){
						$_SESSION['email'] = $_POST['email'];
						header("Location: routeur.php?action=Profile&success=Votre profil a bien été modifié");
					}
				}
			}
				
		}

		public static function DeleteProfile(){
			if(!isset($_SESSION['id']))
			{
				header("Location: routeur.php?action=Accueil&warning=vous devez être connecté");
			}
			$user = Utilisateur::getUser($_SESSION['email']);
			$user->delete();
			session_destroy();
			header("Location: routeur.php?action=Accueil&success=Vous êtes déconnecté");
		}

	}
?>