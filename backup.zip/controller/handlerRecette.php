<?php
	require_once("model/Recette.php");
	require_once("model/Utilisateur.php");
	require_once("model/Commentaire.php");
	require_once("model/Categorie.php");
	require_once("model/Utils.php");
	require_once("model/Etape.php");
	require_once("model/Ingredient.php");
	require_once("config/Connexion.php");
	Connexion::connect();
	class handlerRecette{
		public static function Accueil(){ 
			$pageTitle = "Accueil";
			$pageHeader = "Recettes les plus populaires";
			$lesRecettes=Recette::getRecetteOrderByNote();
			$users = array();
			foreach ($lesRecettes as $recette){
				$users[$recette->getRecetteID()] = Utilisateur::getUserById($recette->getUserID());
			}
			include("view/recettes.php");
		}

		public static function Recettes(){ 
			$pageTitle = "Recettes";
			$pageHeader = "tout les recettes";
			if(isset($_GET['page'])){
				$page = $_GET['page'];
			}else{
				$page = 1;
			}
			$limit = 6;
			$lesRecettes=Recette::getRecetteByPage($page,$limit);
			$users = array();
			foreach ($lesRecettes as $recette){
				$users[$recette->getRecetteID()] = Utilisateur::getUserById($recette->getUserID());
			}
			include("view/recettes.php");
		}

		public static function ViewRecette($id){
			$recette=Recette::getRecette($id);
			$user = Utilisateur::getUserById($recette->getUserID());
			$time = strtotime($recette->getDate());
			$tempsPasse = Utils::get_time_ago($time);
			$username = $user->getUsername();
			$photo = $user->getPhoto();
			$userId = $user->getUserID();
			$etapes = Etape::getEtapeByRecetteID($id);
			$ingredients = Ingredient::getIngredientsByRecetteID($id);
			$nbp = $recette->getNB_Personnes();
			$note = number_format((float)$recette->getNote(), 2, '.', '') . "/5";
			$noteEtoile = round($recette->getNote());
			$lastEtoile = 5 - $noteEtoile;
			$duree = $recette->getDuree() . " min";
			$difficulte = $recette->getNiveau_Difficulte() . "/10";
			$commentaires = Commentaire::getAllCommentaires($id);
			$users = array();
			foreach ($commentaires as $commentaire){
				$users[$commentaire->getCommentaireID()] = Utilisateur::getUserById($commentaire->getUserID());
			}
			if(!$commentaires){
				$commentaires = array();
			}
			if($nbp==1){
				$nbp .= " personne";
			}else{
				$nbp .= " personnes";
			}
			if(!$etapes){
				$etapes = array();
			}
			if(!$ingredients){
				$ingredients = array();
			}
			if(!$recette){
				header("Location: index.php?action=Accueil&error=cette recette n'existe pas");
			}
			include("view/recette.php");
		}


		public static function CreateRecette(){
			if(!isset($_SESSION['username'])){
				header("Location: routeur.php?action=Accueil&warning=Il faut être connecté pour créer une recette");
			}
			if(isset($_SESSION["id"])){
				$userId = $_SESSION["id"];
			}else{
				$userId = Utilisateur::getUser($_SESSION["email"])['UserID'];
			}
			if(isset($_POST["envoyer"])){
				$titre = $_POST["titre"];
				$categories = $_POST["categories"];
				$description = $_POST["description"];
				$hours = $_POST["hours"];
				$minutes = $_POST["minutes"];
				$nbpersonnes = $_POST["nbpersonnes"];
				$difficulte = $_POST["difficulte"];	
				$duree = $hours * 60 + $minutes;
				$image = "images/recettes/default.png";
				$etapes = array();
				$ingredients = array();
				$countEtape = 0;
				$countING = 0;
				$target_dir = "images/recettes/";
				$basename = basename($_FILES["photo"]["name"]);
				//encrypt the file name
				$basename = md5($basename);
				//add file name to the target file + file extension
				$imageFileType = strtolower(pathinfo($_FILES["photo"]["name"],PATHINFO_EXTENSION));
				$target_file = $target_dir . $basename . Utils::genString() . ".$imageFileType";
				$check = getimagesize($_FILES["photo"]["tmp_name"]);
					if($check !== false) {
						$image = $target_file;
						if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
						&& $imageFileType != "gif" ){
							header("Location: routeur.php?action=Profile&error=Désolé, seuls les fichiers JPG, JPEG, PNG et GIF sont autorisés");
						}
						if($_FILES["photo"]["size"] > 500000){
							header("Location: routeur.php?action=Profile&error=Désolé, votre fichier est trop volumineux");
						}
						if(file_exists($target_file)){
							header("Location: routeur.php?action=Profile&error=Désolé, le fichier existe déjà");
						}
						move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file);
					} else {
						header("Location: routeur.php?action=Profile&error=Désolé, votre fichier n'a pas été téléchargé");
					}
					
				foreach($_POST as $key => $value){
					if($key == "envoyer"){
						continue;
					}
					if($value == ""){
						header("Location: routeur.php?action=CreateRecette&error=Vous devez remplir tous les champs");
					}
					if(strpos($key,"etape") !== false){
						$etapes[$countEtape]['description'] = $value;
						$countEtape++;
					}else if(strpos($key,"ingredient") !== false){
						if(strpos($key,"ingredient-nom-") !== false){
							$ingredients[$countING]['nom'] = $value;
						}else if(strpos($key,"ingredient-quantite-") !== false){
							$ingredients[$countING]['quantite'] = $value;
						}
						if(strpos($key,"ingredient-unite-") !== false){
							$ingredients[$countING]['unite'] = $value;
							$countING++;
						}
						
					}

					
				}
				$etapeCounter = 0;
				$INGCounter = 0;
				foreach($etapes as $etape){
					if(Etape::addEtape(Recette::NombreRecette(),$etape['description'],$etapeCounter)){
						$etapeCounter++;
					}else{
						header("Location: routeur.php?action=CreateRecette&error=Une erreur est survenue lors de l'ajout des étapes: etape $etapeCounter");
					}
				}
				foreach($ingredients as $ingredient){
					if(Ingredient::addIngredient(Recette::NombreRecette(),$ingredient['nom'],$ingredient['quantite'],$ingredient['unite'])){
						$INGCounter++;
					}else{
						header("Location: routeur.php?action=CreateRecette&error=Une erreur est survenue lors de l'ajout des ingrédients: ingredient $INGCounter");
					}
				}
				if(Recette::addRecette($titre,$userId,$description,$image,$duree,$difficulte,$nbpersonnes,$categories)){
					header("Location: routeur.php?action=Accueil&success=Votre recette a été créée");
				}else{
					header("Location: routeur.php?action=Accueil&error=Une erreur est survenue");
				}
			}
		}

		public static function Categories(){
			if(!isset($_GET['id'])){
				header("Location: routeur.php?action=Accueil&error=Cette catégorie n'existe pas");
			}else{
				$id = $_GET['id'];
				$pageHeader = "Catégorie";
				$categorie = Categorie::getCategorieByID($id);
				if(!$categorie){
					header("Location: routeur.php?action=Categories&error=Cette catégorie n'existe pas");
				}
				$pageTitle = $categorie->getNomCategorie();
				$pageHeader = "Les Recettes De la Categorie : ". $categorie->getNomCategorie();
				$lesRecettes = Recette::getRecetteByCategorie($id);
				$users = array();
				foreach ($lesRecettes as $recette){
					$users[$recette->getRecetteID()] = Utilisateur::getUserById($recette->getUserID());
				}
				include("view/recettes.php");
			}
		}

		public static function SearchQuery(){
			$pageTitle = "Recherche";
			$pageHeader = "Resultats de votre recherche : ";
			$userHeader = "Resultats de votre recherche : ";
			if(isset($_POST["submit"]) && isset($_POST["search"])){
				$query = $_POST["search"];
				$lesRecettes = Recette::getRecettesByQuery($query);
				$userSearch = Utilisateur::getUsersByQuery($query);
				if(!$userSearch){
					$userSearch = array();
				} 
				if(!$lesRecettes){
					$lesRecettes = array();
				}
				if(count($lesRecettes) == 1){
					$pageHeader = $pageHeader." <strong>".count($lesRecettes)."</strong> recette";
				}else{
					$pageHeader = $pageHeader." <strong>".count($lesRecettes)."</strong> recettes";
				}
				if(count($userSearch) == 1){
					$userHeader = $userHeader." <strong>".count($userSearch)."</strong> Utilisateur";
				}else{
					$userHeader = $userHeader." <strong>".count($userSearch)."</strong> Utilisateurs";
				}
				$users = array();
				foreach ($lesRecettes as $recette){
					$users[$recette->getRecetteID()] = Utilisateur::getUserById($recette->getUserID());
				}
				$limit = 0;
				include("view/recettes.php");
			}else
			{
				header("Location: routeur.php?action=Accueil");
			}
		}
		public static function AddCommentaire()
		{
			if(isset($_POST["envoyer"])){
				$commentaire = $_POST["commentaire"];
				$recetteId = $_POST["recetteId"];
				$userId = $_SESSION["id"];
				$note = 0;
				if(isset($_POST["5"])){
					$note = 5;
				}else if (isset($_POST["4"])){
					$note = 4;
				}else if (isset($_POST["3"])){
					$note = 3;
				}else if (isset($_POST["2"])){
					$note = 2;
				}else if (isset($_POST["1"])){
					$note = 1;
				}
				if(Commentaire::addCommentaire($recetteId,$userId,$commentaire,$note)){
					header("Location: routeur.php?action=ViewRecette&id=".$recetteId."&success=Votre commentaire a été ajouté");
				}else{
					header("Location: routeur.php?action=ViewRecette&id=".$recetteId."&error=Une erreur est survenue lors de l'ajout de votre commentaire");
				}
			}
		}

		public static function EditRecette(){
			if(!isset($_SESSION['username'])){
				header("Location: routeur.php?action=Accueil&warning=Vous devez être connecté pour accéder à cette page");
			}
			if(!isset($_POST['submitedit'])){
				if(!isset($_GET['id'])){
					header("Location: routeur.php?action=Accueil&error=Cette recette n'existe pas");
				}
				$id = $_GET['id'];
				$recette = Recette::getRecette($id);
				if(!$recette){
					header("Location: routeur.php?action=Accueil&error=Cette recette n'existe pas");
				}
				if($recette->getUserID() != $_SESSION['id']){
					header("Location: routeur.php?action=Accueil&error=Vous n'avez pas le droit d'éditer cette recette");
				}
				$etapes = Etape::getEtapeByRecetteID($id);
				$ingredients = Ingredient::getIngredientsByRecetteID($id);
				if(!$etapes){
					$etapes = array();
				}
				if(!$ingredients){
					$ingredients = array();
				}
				$heures = floor($recette->getDuree()/60);
				$minutes = $recette->getDuree()%60;
				include("view/editRecette.php");
			}else{
				echo "<pre>";
				print_r($_POST);
				echo "</pre>";
				$titre = $_POST["titre"];
				$categories = $_POST["categories"];
				$description = $_POST["description"];
				$hours = $_POST["hours"];
				$minutes = $_POST["minutes"];
				$nbpersonnes = $_POST["nbpersonnes"];
				$difficulte = $_POST["difficulte"];	
				$duree = $hours * 60 + $minutes;
				$image = "images/recettes/default.png";
				$etapes = array();
				$ingredients = array();
				$countEtape = 0;
				$countING = 0;
				$target_dir = "images/recettes/";
				if(isset($_FILES['photo'])){
					$basename = basename($_FILES["photo"]["name"]);
				//encrypt the file name
					$basename = md5($basename);
					//add file name to the target file + file extension
					$imageFileType = strtolower(pathinfo($_FILES["photo"]["name"],PATHINFO_EXTENSION));
					$target_file = $target_dir . $basename . Utils::genString() . ".$imageFileType";
					$check = getimagesize($_FILES["photo"]["tmp_name"]);
					if($check !== false) {
						$image = $target_file;
						if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
						&& $imageFileType != "gif" ){
							header("Location: routeur.php?action=Profile&error=Désolé, seuls les fichiers JPG, JPEG, PNG et GIF sont autorisés");
						}
						if($_FILES["photo"]["size"] > 500000){
							header("Location: routeur.php?action=Profile&error=Désolé, votre fichier est trop volumineux");
						}
						if(file_exists($target_file)){
							header("Location: routeur.php?action=Profile&error=Désolé, le fichier existe déjà");
						}
						move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file);
					} else {
						header("Location: routeur.php?action=Profile&error=Désolé, votre fichier n'a pas été téléchargé");
					}
				}else{
					$image = $_POST["oldFile"];
				}
					
				foreach($_POST as $key => $value){
					if($key == "envoyer"){
						continue;
					}
					if(strpos($key,"etape-id") !== false){
						$etapes[$countEtape]['id'] = $value;
						$countEtape++;
					}else if(strpos($key,"etape") !== false){
						$etapes[$countEtape]['description'] = $value;
					}else if(strpos($key,"ingredient") !== false){
						if(strpos($key,"ingredient-nom-") !== false){
							$ingredients[$countING]['nom'] = $value;
						}else if(strpos($key,"ingredient-quantite-") !== false){
							$ingredients[$countING]['quantite'] = $value;
						}else if(strpos($key,"ingredient-id-") !== false){
							$ingredients[$countING]['id'] = $value;
							$countING++;
						}else if(strpos($key,"ingredient-unite-") !== false){
							$ingredients[$countING]['unite'] = $value;
						}
					}
				}
				$recette_id = $_POST["recette-id"];
				$etapeCounter = 0;
				$INGCounter = 0;
				$allIngforRec = Ingredient::getIngredientsByRecetteID($recette_id);
				$allEtapeforRec = Etape::getEtapeByRecetteID($recette_id);
				if(!$allIngforRec){
					$allIngforRec = array();
				}
				if(!$allEtapeforRec){
					$allEtapeforRec = array();
				}
				foreach($allIngforRec as $ing){
					$ing->delete();
				}
				foreach($allEtapeforRec as $etape){
					$etape->delete();
				}
				foreach($etapes as $etape){
					// if(isset($etape['id'])){
					// 	if(Etape::editEtape($etape['id'],$etape['description'],$etapeCounter)){
					// 		$etapeCounter++;
					// 	}else{
					// 		header("Location: routeur.php?action=EditRecette&error=Une erreur est survenue lors de la modification des étapes: etape $etapeCounter");
					// 	}
					//}else{
					if(Etape::addEtape($recette_id,$etape['description'],$etapeCounter)){
							$etapeCounter++;
					}else{
							header("Location: routeur.php?action=EditRecette&error=Une erreur est survenue lors de la création des étapes: etape $etapeCounter");
					}
					//}
					
				}
				foreach($ingredients as $ingredient){
					// if(isset($ingredient['id'])){
					// 	if(Ingredient::editIngredient($ingredient['id'],$ingredient['nom'],$ingredient['quantite'],$ingredient['unite'])){
					// 		$INGCounter++;
					// 	}else{
					// 		header("Location: routeur.php?action=EditRecette&error=Une erreur est survenue lors de la modification des ingrédients: ingredient $INGCounter");
					// 	}

					// }else{
					if(Ingredient::addIngredient($recette_id,$ingredient['nom'],$ingredient['quantite'],$ingredient['unite'])){
						$INGCounter++;
					}else{
						header("Location: routeur.php?action=EditRecette&error=Une erreur est survenue lors de la création des ingrédients: ingredient $INGCounter");
					}
					// }
					
				}
				if(Recette::editRecette($recette_id,$titre,$description,$image,$duree,$difficulte,$nbpersonnes,$categories)){
					header("Location: routeur.php?action=ViewRecette&id=$recette_id&success=Votre recette a été modifier avec succès");
				}else{
					header("Location: routeur.php?action=Accueil&error=Une erreur est survenue");
				}
			}
		}
		public static function DeleteRecette(){
			if(!isset($_SESSION['id'])){
				header("Location: routeur.php?action=Accueil&waning=Vous devez être connecté pour accéder à cette page");
			}
			if(isset($_GET['id'])){
				$recette_id = $_GET['id'];
				$recette = Recette::getRecette($recette_id);
				echo "<pre>";
				print_r($recette);
				echo "</pre>";
				if($recette){
					if(intval($recette->getUserID()) != intval($_SESSION['id'])){
						header("Location: routeur.php?action=Accueil&error=Vous n'avez pas le droit d'accéder à cette page");}
					$recette->delete();
					header("Location: routeur.php?action=Profile&success=Votre recette a été supprimer avec succès");
				}else{
					header("Location: routeur.php?action=Accueil&error=Une erreur est survenue");
				}
			}
		}



		public static function ApproveComment(){
			if(!isset($_SESSION['id'])){
				header("Location: routeur.php?action=Accueil&waning=Vous devez être connecté pour accéder à cette page");
			}
			if(!isset($_GET['id'])){
				header("Location: routeur.php?action=Accueil&error=ce commentaire n'existe pas");
			}
			$comment_id = $_GET['id'];
			$comment = Commentaire::getCommentaireByID($comment_id);
			$recette = Recette::getRecette($comment->getRecetteID());
			if(!$comment){
				header("Location: routeur.php?action=Accueil&error=ce commentaire n'existe pas");
			}
			$user = Utilisateur::getUserById($recette->getUserID());
			if(!$user){
				header("Location: routeur.php?action=Accueil&error=ce commentaire n'existe pas");
			}
			if(intval($user->getUserID()) != intval($_SESSION['id'])){
				header("Location: routeur.php?action=Accueil&error=Vous n'avez pas le droit d'accéder à cette page");
			}

			if($comment->updateStatut(1))
				header("Location: routeur.php?action=Profile&tab=2&success=Le commentaire a été approuvé");
			else
				header("Location: routeur.php?action=Profile&tab=2&error=Une erreur est survenue");
		}


		public static function DeleteComment(){
			if(!isset($_SESSION['id'])){
				header("Location: routeur.php?action=Accueil&waning=Vous devez être connecté pour accéder à cette page");
			}
			if(!isset($_GET['id'])){
				header("Location: routeur.php?action=Accueil&error=ce commentaire n'existe pas");
			}
			$comment_id = $_GET['id'];
			$comment = Commentaire::getCommentaireByID($comment_id);
			$recette = Recette::getRecette($comment->getRecetteID());
			if(!$comment){
				header("Location: routeur.php?action=Accueil&error=ce commentaire n'existe pas");
			}
			$user = Utilisateur::getUserById($recette->getUserID());
			if(!$user){
				header("Location: routeur.php?action=Accueil&error=ce commentaire n'existe pas");
			}
			if(intval($user->getUserID()) != intval($_SESSION['id'])){
				header("Location: routeur.php?action=Accueil&error=Vous n'avez pas le droit d'accéder à cette page");
			}

			if($comment->delete())
				header("Location: routeur.php?action=Profile&tab=2&success=Le commentaire a été approuvé");
			else
				header("Location: routeur.php?action=Profile&tab=2&error=Une erreur est survenue");
		}







	}

?>