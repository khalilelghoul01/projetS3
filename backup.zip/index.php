<?php
header('location: routeur.php?action=Accueil');
?>