<div class="text-center">
    <h1><?php echo $userHeader; ?></h1>
</div>
<ul class="cards">
    <?php foreach ($userSearch as $user) : ?>
        <?php
        $username = $user->getUsername();
        $userId = $user->getUserID();
        $time = strtotime($user->getDate());
        $tempsPasse = Utils::get_time_ago($time);
        $userPhoto = $user->getPhoto();
        ?>
        <li>
            <a href="routeur.php?action=Profile&id=<?php echo $userId; ?>" class="card_users">
                <div class="card__header_users">
                    <img class="card__thumb" src="<?php echo $userPhoto; ?>" alt="" />
                    <div class="card__header-text">
                        <h3 class="card__title"><?php echo $username; ?></h3>
                        <span class="card__status"><?php echo $tempsPasse; ?></span>
                    </div>
            </a>
        </li>

    <?php endforeach; ?>
</ul>