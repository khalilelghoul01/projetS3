<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $pageTitle;?></title>
	<link href="style/accueil/css/main.css" rel="stylesheet">
</head>

<body>
	<?php
	include 'view/navbar.php';
	?>
	<div class="text-center"><h1><?php echo $pageHeader;?></h1></div>
	<ul class="cards">
		<?php foreach ($lesRecettes as $recette) : ?>
			<?php
			$recetteID = $recette->getRecetteID();
			$user = $users[$recetteID];
			$username = $user->getUsername();
			$userId = $user->getUserID();
			$time = strtotime($recette->getDate());
			$tempsPasse = Utils::get_time_ago($time);
			$title = $recette->getTitre();
			$thumbnail = $recette->getThumbnail();
			$userPhoto = $user->getPhoto();
			?>
			<li>
				<a href="routeur.php?action=ViewRecette&id=<?php echo $recetteID; ?>" class="card">
					<img src="<?php echo $thumbnail; ?>" class="card__image" alt="" />
					<div class="card__overlay">
						<div class="card__header">
							<svg class="card__arc" xmlns="http://www.w3.org/2000/svg">
								<path />
							</svg>
							<img class="card__thumb" src="<?php echo $userPhoto; ?>" alt="" />
							<div class="card__header-text">
								<h3 class="card__title"><?php echo $title; ?></h3>
								<h2 class="card__tagline" ><?php echo $username; ?></h2>
								<span class="card__status"><?php echo $tempsPasse; ?></span>
								
							</div>
						</div>
					</div>
				</a>
			</li>

		<?php endforeach; ?>
	</ul>

	<?php 
	if(isset($userSearch)){
		include 'view/userSearch.php';
	}

	if($_GET['action'] == 'Recettes'){
		include 'view/allRecette.php';
	}
	?>
</body>

</html>