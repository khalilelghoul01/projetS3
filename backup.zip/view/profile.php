<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style/profile/css/profile.css">
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
  <link href="style/fontawesome/css/all.css" rel="stylesheet">
  <link href="style/accueil/css/main.css" rel="stylesheet">
  <title><?php echo "@" . $username; ?></title>
</head>

<body>
  <?php
  include 'view/navbar.php';
  $categories = Categorie::getAllCategories();
  ?>
  <div class="ui-bg-cover ui-bg-overlay-container text-white" style="background-color: #da94bd;">
    <div class="ui-bg-overlay bg-img-blur"></div>
    <div class="container">
      <div class="text-center py-5">
        <img src="<?php echo $userPhoto; ?>" alt="" class="ui-w-100 border border-3 border-white rounded-circle" style="object-fit: cover;">

        <div class="col-md-8 col-lg-6 col-xl-5 p-0 mx-auto">
          <h4 class="font-weight-bold my-4"><?php echo "@" . $username; ?></h4>

          <div class="opacity-75 mb-4">
            <?php echo $bio; ?>
          </div>
        </div>

        <div class="text-center">
          <a href="javascript:void(0)" class="d-inline-block text-white">
            <strong><?php echo $nbRecettesPerUser; ?></strong>
            <span><strong>Recettes</strong></span>
          </a>
        </div>
        <?php if (isset($_SESSION['username']) && $username == $_SESSION['username']) :  ?>
          <br>
          <a class="btn btn-warning mr-2" href="routeur.php?action=Profile&tab=2">voir les commentaires</a><a class="btn btn-success mr-2" href="routeur.php?action=Profile&tab=1">Voir les recettes</a><a class="btn btn-danger" href="routeur.php?action=DeleteProfile">supprimer votre profile</a>
        <?php endif; ?>
      </div>
    </div>


  </div>
  <div class="text-center mt-2">
    <?php if (isset($_SESSION['username']) && $username == $_SESSION['username']) :  ?>
      <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#ajouterRecette"><i class="far fa-plus-square"></i> Ajouter une recette</button>
    <?php endif; ?>
    <div class="modal fade" id="ajouterRecette" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Nouvelle recette</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">

            <form action="routeur.php" method="POST" enctype="multipart/form-data">
              <input type="hidden" name="action" value="CreateRecette">
              <div class="mb-3">
                <label for="Titre" class="col-form-label">Titre:</label>
                <input type="text" class="form-control" id="Titre" name="titre" required>
              </div>
              <div class="mb-3">
                <label for="image" class="col-form-label">Image:</label>
                <input type="file" class="form-control" id="image" name="photo" accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*" required>
              </div>
              <div class="mb-3">
                <label for="categories" class="col-form-label">Categories:</label>
                <select class="form-control" id="categories" name="categories" required>
                  <?php foreach ($categories as $categorie) :  ?>
                    <option value="<?php echo $categorie->getCategorieID(); ?>"><?php echo $categorie->getNomCategorie(); ?></option>
                  <?php endforeach; ?>

                </select>
              </div>
              <div class="mb-3">
                <label for="description" class="col-form-label">Description:</label>
                <textarea class="form-control" id="description" name="description" required></textarea>
              </div>
              <div class="mb-3">
                <div class="row">
                  <div class="col">
                    <label for="description" class="col-form-label">Etapes:</label>
                  </div>
                  <div class="col">
                    <button type="button" onClick="jqueryStuffAdd()" class="btn btn-success" name="ajouter"><i class="far fa-plus-square"></i></button>
                  </div>
                </div>
                <div class="row">
                  <div class="mb-3" id="ajouter"></div>
                </div>
              </div>

              <div class="mb-3">
                <div class="row">
                  <div class="col">
                    <label for="description" class="col-form-label">Ingredients:</label>
                  </div>
                  <div class="col">
                    <button type="button" onClick="jqueryStuffAddIngredient()" class="btn btn-success" name="ajouter"><i class="far fa-plus-square"></i></button>
                  </div>
                </div>
                <div class="row">
                  <div class="mb-3" id="ajouterING"></div>
                </div>
              </div>


              <div class="container mb-3">
                <div class="row">
                  <label for="time" class="col-form-label">Durée:</label>
                </div>
                <div class="row">
                  <div class="col">
                    <input type='number' class="form-control" name="hours" placeholder="heures" min="0" max="48" required />
                  </div>
                  <div class="col">
                    <input type='number' class="form-control" name="minutes" placeholder="minutes" min="0" max="59" required />
                  </div>
                </div>
              </div>
              <div class="container mb-3">
                <div class="row">
                  <div class="col">
                    <label for="time" class="col-form-label">Nombres de personnes:</label>
                    <input type='number' class="form-control" name="nbpersonnes" placeholder="Nombres de personnes " min="0" max="20" required />
                  </div>
                  <div class="col">
                    <label for="time" class="col-form-label">Difficulté:</label>

                    <input type='number' class="form-control" name="difficulte" placeholder="Difficulté" min="1" max="10" required />
                  </div>
                </div>
              </div>
              <div class="container mb-3">
                <div class="row">
                  <div class="col">
                    <button type="submit" class="btn btn-danger" name="envoyer">Créer</button>
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">fermer</button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php
  if ($tab == 1) : ?>
    <ul class="cards">
      <?php foreach ($userRecette as $recette) : ?>
        <?php
        $time = strtotime($recette->getDate());
        $tempsPasse = Utils::get_time_ago($time);
        $title = $recette->getTitre();
        $thumbnail = $recette->getThumbnail();
        $recetteID = $recette->getRecetteID();
        ?>
        <li>
          <a href="routeur.php?action=ViewRecette&id=<?php echo $recetteID; ?>" class="card">
            <img src="<?php echo $thumbnail; ?>" class="card__image" alt="" />
            <div class="card__overlay">
              <div class="card__header">
                <svg class="card__arc" xmlns="http://www.w3.org/2000/svg">
                  <path />
                </svg>
                <img class="card__thumb" src="<?php echo $userPhoto; ?>" alt="" />
                <div class="card__header-text">
                  <h1 class="card__title"><?php echo $title; ?></h1>
                  <h2 class="card__tagline"><?php echo $username; ?></h2>
                  <span class="card__status"><?php echo $tempsPasse; ?></span>

                </div>
              </div>
            </div>
          </a>
        </li>

      <?php endforeach; ?>
    </ul>
  <?php else : ?>
    <?php
    $commentaires = Commentaire::getCommentaireByUserRecetteID($userId);
    foreach ($commentaires as $commentaire) {
      $statut = $commentaire->getStatut();
      if ($statut == 0) {
        $commentaireUser = Utilisateur::getUserById($commentaire->getUserID());
        $time = strtotime($commentaire->getDate());
        $tempsPasse = Utils::get_time_ago($time);
        echo "<div class='container'>";
        echo "<div class='card-commentaire  p-3 mt-2'>
    <div class='d-flex justify-content-between align-items-center'>
      <div class='user d-flex flex-row align-items-center'>
        <img src='" .  $commentaireUser->getPhoto() . "' width='40' height='40' class='user-img rounded-circle mr-5' style='object-fit: cover;' />
        <span>
        <br>
        <br>
          <strong class='font-weight-bold text-primary'>@" .  $commentaireUser->getUsername() . "</strong>
          <small class='font-weight-bold'>" .  $commentaire->getText() . "</small></span>
      </div>
      <small>" .  $tempsPasse . "</small>
    </div>
    <div class='action d-flex justify-content-between mt-2 align-items-center'>
      <div class='reply px-4'>
        <a href='routeur.php?action=DeleteComment&id=" . $commentaire->getCommentaireID() . "'>supprimer</a> <span class='dots'></span>
        <a href='routeur.php?action=ApproveComment&id=" . $commentaire->getCommentaireID() . "'>Approver</a> <span class='dots'></span>
      </div>
      <div class='icons align-items-center'>
        <i class='fa fa-check-circle-o check-icon text-primary'></i>
      </div>
    </div>
  </div></div>";
      }
    }
    ?>
  <?php endif; ?>
  <script>
    var counter = 0;
    var counterIng = 0;

    function jqueryStuffAdd() {
      counter++;
      var div = document.createElement("div");
      div.innerHTML = "<div class='row mb-1' id='etape-id-" + counter + "'><div class='col'><textarea type='text' class='form-control' name='etape-" + counter + "' placeholder='Etape " + counter + "' required></textarea></div><div class='col-2'><button type='button' id='" + counter + "' onClick='jqueryStuffDelete(this.id)' class='btn btn-danger' name='supprimer'><i class='far fa-minus-square'></i></button></div></div>";
      document.getElementById("ajouter").parentNode.appendChild(div);
    }

    function jqueryStuffAddIngredient() {
      counterIng++;
      var div = document.createElement("div");
      div.innerHTML = "<div class='row mb-1' id='ingredient-id-" + counterIng + "'>  <div class='col-4'>    <input      type='text'      class='form-control'      name='ingredient-nom-" + counterIng + "'      placeholder='Nom Ingredient " + counterIng + "'      required    >  </div><div class='col'>    <input      type='number'      class='form-control'  max='1000' min='1'      name='ingredient-quantite-" + counterIng + "'      placeholder='Quatité'      required    >  </div><div class='col'>    <select  class='form-control'      name='ingredient-unite-" + counterIng + "' required    ><option value='kg'>kg</option><option value='g'>g</option><option value='litre'>litre</option><option value='ml'>millilitre</option><option value='cuillere'>cuillère</option><option value='unite'>unite</option></select>  </div>  <div class='col-2'>    <button      type='button'      id='" + counterIng + "'      onClick='jqueryStuffDeleteIng(this.id)'      class='btn btn-danger'      name='supprimer'    >      <i class='far fa-minus-square'></i>    </button>  </div></div>";
      document.getElementById("ajouterING").parentNode.appendChild(div);
    }

    function jqueryStuffDelete(id) {
      if (counter > 0) {
        document.getElementById("ajouter").parentNode.removeChild(document.getElementById("etape-id-" + id).parentNode);
        counter--;
      }
    }

    function jqueryStuffDeleteIng(id) {
      if (counterIng > 0) {
        document.getElementById("ajouterING").parentNode.removeChild(document.getElementById("ingredient-id-" + id).parentNode);
        counter--;
      }
    }
  </script>
</body>

</html>