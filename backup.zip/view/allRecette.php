<nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
    <li class="page-item disabled">
      <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
    </li>
    <?php if($limit == 0){
      $limit = 1;
    }?>
    <?php for ($i = 0; $i < ceil(intval(Recette::getTotalRecette()) / $limit); $i++) : ?>
      <li class="page-item"><a class="page-link" href="routeur.php?action=Recettes&page=<?php echo $i+1; ?>"><?php echo $i+1; ?></a></li>
    <?php endfor; ?>
    <li class="page-item">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav>