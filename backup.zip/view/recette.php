<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <link href="style/recette/css/main.css" rel="stylesheet">
    <link href="style/fontawesome/css/all.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <title>Accueil (avant connection)</title>

</head>

<body>
    <?php
    include 'view/navbar.php';
    ?>

    <header>
        <!-- <div class="bg-wrapper" ></div> -->
        <div class="info-wrapper bg-wrapper" style="	background: url('<?php echo htmlentities($recette->getThumbnail()); ?>');background-position: center;background-repeat: no-repeat;background-size: cover;">
            <div class="holder">
                <h1 class="headline"><?php echo htmlentities($recette->getTitre()); ?></h1>
                <div class="article-meta">
                    <a href="routeur.php?action=Profile&id=<?php echo $userId; ?>"><img id="author-avatar" width="80" height="80" src="<?php echo htmlentities($photo); ?>" />
                        <p class="byline">Par <?php echo "@" . htmlentities($username); ?></p>
                    </a>
                    <p class="dateline"><?php echo htmlentities($recette->getDate()); ?></p>
                    <p class="dateline"><?php echo htmlentities($tempsPasse); ?></p>
                    <p class="article-tags">
                        <span class="tag"><?php echo Categorie::getCategorieByID($recette->getCategorie())->getNomCategorie(); ?></span>
                    </p>
                    <div>
                        <?php for ($i = 0; $i < $noteEtoile; $i++) : ?>
                            <i class="fas fa-star" style="color: yellow;"></i>
                        <?php endfor; ?>
                        <?php for ($i = 0; $i < $lastEtoile; $i++) : ?>
                            <i class="far fa-star"></i>
                        <?php endfor;
                        echo $note; ?>
                    </div>
                    <?php if (isset($_SESSION['id'])) : ?>
                        <?php if (intval($userId) == intval($_SESSION['id'])) : ?>
                            <a type="button" class="btn btn-success" href = "routeur.php?action=EditRecette&id=<?php echo $recette->getRecetteId(); ?>"><i class="fas fa-edit" ></i> Editer cette recette</a>
                            <a type="button" class="btn btn-danger" href = "routeur.php?action=DeleteRecette&id=<?php echo $recette->getRecetteId(); ?>"><i class="fas fa-edit" ></i> Supprimer cette recette</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <section>
        <!-- <form action="">
            <input class="star star-5" id="star-5" type="radio" name="star" />
            <label class="star star-5" for="star-5"></label>
            <input class="star star-4" id="star-4" type="radio" name="star" />
            <label class="star star-4" for="star-4"></label>
            <input class="star star-3" id="star-3" type="radio" name="star" />
            <label class="star star-3" for="star-3"></label>
            <input class="star star-2" id="star-2" type="radio" name="star" />
            <label class="star star-2" for="star-2"></label>
            <input class="star star-1" id="star-1" type="radio" name="star" />
            <label class="star star-1" for="star-1"></label>
        </form> -->
        <h2>Detail:</h2>
        <p>
            <?php echo "$nbp $duree $difficulte" ?>
        </p>
    </section>

    <section>
        <h2>Description:</h2>
        <p>
            <?php echo htmlentities($recette->getDescription()); ?>
        </p>
    </section>

    <?php if (count($etapes) > 0) : ?>
        <section>
            <h2>Etapes:</h2>
            <ol class="custom-counter">
                <?php
                foreach ($etapes as $etape) {
                    echo "<li>" . htmlentities($etape->getText()) . "</li>";
                }
                ?>
            </ol>
        </section>
    <?php endif; ?>
    <?php if (count($ingredients) > 0) : ?>
        <section>
            <h2>Ingredients:</h2>
            <ol class="custom-counter">
                <?php
                foreach ($ingredients as $ing) {
                    echo "<li>" . htmlentities($ing->getNomIngredient()) . " : " . htmlentities($ing->getQuantiteIngredient()) . " " . htmlentities($ing->getUniteIngredient()) . "</li>";
                }
                ?>
            </ol>
        </section>
    <?php endif; ?>
    <br>
    <div class="container mt-5">
        <div class="row d-flex justify-content-center">
            <div class="col-md-8">
                <div class="headings d-flex justify-content-between align-items-center mb-3">
                    <h5>Commentaires</h5>
                </div>
                <?php if (isset($_SESSION['username'])) :  ?>
                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#ajouterCommentaire"><i class="far fa-plus-square"></i> Ajouter un commentaire</button>

                    <div class="modal fade" id="ajouterCommentaire" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Commentaire</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="routeur.php" method="POST">
                                        <input type="hidden" name="action" value="AddCommentaire">
                                        <input type="hidden" name="recetteId" value="<?php echo $_GET['id']; ?>">
                                        <div class="mb-3">
                                            <input class="star star-5" id="star-5" type="radio" name="5" />
                                            <label class="star star-5" for="star-5"></label>
                                            <input class="star star-4" id="star-4" type="radio" name="4" />
                                            <label class="star star-4" for="star-4"></label>
                                            <input class="star star-3" id="star-3" type="radio" name="3" />
                                            <label class="star star-3" for="star-3"></label>
                                            <input class="star star-2" id="star-2" type="radio" name="2" />
                                            <label class="star star-2" for="star-2"></label>
                                            <input class="star star-1" id="star-1" type="radio" name="1" />
                                            <label class="star star-1" for="star-1"></label>
                                        </div>
                                        <div class="mb-3">
                                            <textarea class="form-control" id="message-text" name="commentaire" maxlength="200" required></textarea>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-danger" name="envoyer">Envoyer</button>
                                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Fermer</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                <?php endif; 
                $cookie = false;
                ?>
                <?php foreach ($commentaires as $commentaire) : ?>
                    <?php
                    $statut = $commentaire->getStatut();
                    $commentaireUser = $users[$commentaire->getCommentaireID()];
                    $time = strtotime($commentaire->getDate());
                    $tempsPasse = Utils::get_time_ago($time);
                    if ($statut == 1) :
                    ?>
                        <div class="card p-3 mt-2">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="user d-flex flex-row align-items-center">
                                    <img src="<?php echo $commentaireUser->getPhoto(); ?>" width="40" height="40" class="user-img rounded-circle mr-5" style="object-fit: cover;" />
                                    <span>
                                        <strong class="font-weight-bold text-primary">@<?php echo $commentaireUser->getUsername(); ?></strong>
                                        <small class="font-weight-bold"><?php echo $commentaire->getText(); ?></small></span>
                                </div>
                                <small><?php echo $tempsPasse; ?></small>
                            </div>
                            <div class="action d-flex justify-content-between mt-2 align-items-center">
                                <div class="reply px-4">
                                    <small>Signaler</small> <span class="dots"></span>
                                </div>
                                <div class="icons align-items-center">
                                    <i class="fa fa-check-circle-o check-icon text-primary"></i>
                                </div>
                            </div>
                        </div>
                    <?php else : ?>
                        <?php 
                        if(isset($_SESSION['id']))
                        {
                            if (intval($commentaire->getUserID()) == intval($_SESSION['id']))
                            {
                                $cookie = true;// = "si vous ne voyez pas votre commentaire alors il n'est pas encore apprové ou il contient des insultes ";
                            }
                        }
                        ?>
                    <?php endif; ?>

                <?php endforeach; ?>
                <?php if ($cookie) : ?>
                    <br><br>
                    <div class="alert alert-warning" role="alert">
                    si vous ne voyez pas votre commentaire alors il n'est pas encore apprové ou il contient des insultes 
                    </div>
                <?php endif; ?>



            </div>
        </div>
    </div>
    <br>
    <br>
    <script>
    var counter = 0;
    var counterIng=0;

    function jqueryStuffAdd() {
      counter++;
      var div = document.createElement("div");
      div.innerHTML = "<div class='row mb-1' id='etape-id-" + counter + "'><div class='col'><textarea type='text' class='form-control' name='etape-" + counter + "' placeholder='Etape " + counter + "' required></textarea></div><div class='col-2'><button type='button' id='" + counter + "' onClick='jqueryStuffDelete(this.id)' class='btn btn-danger' name='supprimer'><i class='far fa-minus-square'></i></button></div></div>";
      document.getElementById("ajouter").parentNode.appendChild(div);
    }

    function jqueryStuffAddIngredient() {
      counterIng++;
      var div = document.createElement("div");
      div.innerHTML = "<div class='row mb-1' id='ingredient-id-" + counterIng + "'>  <div class='col-4'>    <input      type='text'      class='form-control'      name='ingredient-nom-" + counterIng + "'      placeholder='Nom Ingredient " + counterIng + "'      required    >  </div><div class='col'>    <input      type='number'      class='form-control'  max='1000' min='1'      name='ingredient-quantite-" + counterIng + "'      placeholder='Quatité'      required    >  </div><div class='col'>    <select  class='form-control'      name='ingredient-unite-" + counterIng + "' required    ><option value='kg'>kg</option><option value='g'>g</option><option value='litre'>litre</option><option value='ml'>millilitre</option><option value='cuillere'>cuillère</option><option value='unite'>unite</option></select>  </div>  <div class='col-2'>    <button      type='button'      id='" + counterIng + "'      onClick='jqueryStuffDeleteIng(this.id)'      class='btn btn-danger'      name='supprimer'    >      <i class='far fa-minus-square'></i>    </button>  </div></div>";
      document.getElementById("ajouterING").parentNode.appendChild(div);
    }

    function jqueryStuffDelete(id) {
      if (counter > 0) {
        document.getElementById("ajouter").parentNode.removeChild(document.getElementById("etape-id-" + id).parentNode);
        counter--;
      }
    }

    function jqueryStuffDeleteIng(id) {
      if (counterIng > 0) {
        document.getElementById("ajouterING").parentNode.removeChild(document.getElementById("ingredient-id-" + id).parentNode);
        counter--;
      }
    }
  </script>
</body>

</html>