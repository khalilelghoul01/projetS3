<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style/fontawesome/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="style/editRecette/css/main.css">
    <title>Modifier une recette</title>
</head>

<body>
    <?php
    include 'view/navbar.php';
    ?>

    <div class="formHandler">
        <h1 style="text-align: center;">Modifier la recette</h1>
        <form action="routeur.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="EditRecette">
            <input type="hidden" name="recette-id" value="<?php echo $recette->getRecetteID(); ?>">
            <input type="hidden" name="oldFile" value="<?php echo $recette->getThumbnail(); ?>">
            <div class="mb-3">
                <label for="Titre" class="col-form-label">Titre:</label>
                <input type="text" class="form-control" id="Titre" name="titre" value="<?php echo $recette->getTitre(); ?>" required>
            </div>
            <div class="mb-3">
                <label for="image" class="col-form-label">Image:</label>
                <input type="file" class="form-control" id="image" name="photo" accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
            </div>
            <div class="mb-3">
                <label for="categories" class="col-form-label">Categories:</label>
                <select class="form-control" id="categories" name="categories" >
                    <?php foreach ($categories as $categorie) :  ?>
                        <option value="<?php echo $categorie->getCategorieID(); ?>"><?php echo $categorie->getNomCategorie(); ?></option>
                    <?php endforeach; ?>

                </select>
            </div>
            <div class="mb-3">
                <label for="description" class="col-form-label">Description:</label>
                <textarea class="form-control" id="description" name="description" required><?php echo $recette->getTitre(); ?></textarea>
            </div>
            <div class="mb-3">
                <div class="row">
                    <div class="col">
                        <label for="description" class="col-form-label">Etapes:</label>
                    </div>
                    <div class="col">
                        <button type="button" onClick="jqueryStuffAdd()" class="btn btn-success" name="ajouter"><i class="far fa-plus-square"></i></button>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3" id="ajouter">
                    </div>
                    <?php
                    $etapeCounter = 0;
                    foreach ($etapes as $etape) :
                        $etapeCounter++;
                    ?>
                        <div>
                            <div class='row mb-1' id='etape-id-<?php echo $etapeCounter; ?>'>
                                <div class='col'><textarea type='text' class='form-control' name='etape-<?php echo $etapeCounter; ?>' placeholder='Etape <?php echo $etapeCounter; ?>' required><?php echo $etape->getText(); ?></textarea> </div>
                                <div class='col-2'><button type='button' id='<?php echo $etapeCounter; ?>' onClick='jqueryStuffDelete(this.id)' class='btn btn-danger' name='supprimer'><i class='far fa-minus-square'></i></button></div>
                                <input type="hidden" name="etape-id-<?php echo $etapeCounter; ?>" value="<?php echo $etape->getEtapeID(); ?>">
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="mb-3">
                <div class="row">
                    <div class="col">
                        <label for="description" class="col-form-label">Ingredients:</label>
                    </div>
                    <div class="col">
                        <button type="button" onClick="jqueryStuffAddIngredient()" class="btn btn-success" name="ajouter"><i class="far fa-plus-square"></i></button>
                    </div>
                </div>
                <div class="row">
                    <div class="mb-3" id="ajouterING">
                    </div>
                    <?php
                    $ingCounter = 0;
                    foreach ($ingredients as $ingredient) :
                        $ingCounter++;
                    ?>
                        <div>
                            <div class='row mb-1' id='ingredient-id-<?php echo $ingCounter; ?>'>
                                <div class='col-4'> <input type='text' class='form-control' name='ingredient-nom-<?php echo $ingCounter; ?>' placeholder='Nom Ingredient <?php echo $ingCounter; ?>' value="<?php echo $ingredient->getNomIngredient(); ?>" required> </div>
                                <div class='col'> <input type='number' class='form-control' max='1000' min='1' name='ingredient-quantite-<?php echo $ingCounter; ?>' placeholder='Quatité' value="<?php echo $ingredient->getQuantiteIngredient(); ?>" required> </div>
                                <div class='col'> <select class='form-control' name='ingredient-unite-<?php echo $ingCounter; ?>' required>
                                        <option value='kg'>kg</option>
                                        <option value='g'>g</option>
                                        <option value='litre'>litre</option>
                                        <option value='ml'>millilitre</option>
                                        <option value='cuillere'>cuillère</option>
                                        <option value='unite'>unite</option>
                                    </select> </div>
                                <div class='col-2'> <button type='button' id='<?php echo $ingCounter; ?>' onClick='jqueryStuffDeleteIng(this.id)' class='btn btn-danger' name='supprimer'> <i class='far fa-minus-square'></i> </button> </div>
                                <input type="hidden" name="ingredient-id-<?php echo $ingCounter; ?>" value="<?php echo $ingredient->getIngredientID(); ?>">
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>


            <div class="container mb-3">
                <div class="row">
                    <label for="time" class="col-form-label">Durée:</label>
                </div>
                <div class="row">
                    <div class="col">
                        <input type='number' class="form-control" name="hours" placeholder="heures" min="0" max="48" value="<?php echo $heures; ?>" required />
                    </div>
                    <div class="col">
                        <input type='number' class="form-control" name="minutes" placeholder="minutes" min="0" max="59" value="<?php echo $minutes; ?>" required />
                    </div>
                </div>
            </div>
            <div class="container mb-3">
                <div class="row">
                    <div class="col">
                        <label for="time" class="col-form-label">Nombres de personnes:</label>
                        <input type='number' class="form-control" name="nbpersonnes" placeholder="Nombres de personnes " min="0" max="20" value="<?php echo $recette->getNB_Personnes(); ?>" required />
                    </div>
                    <div class="col">
                        <label for="time" class="col-form-label">Difficulté:</label>

                        <input type='number' class="form-control" name="difficulte" placeholder="Difficulté" min="1" max="10" value="<?php echo $recette->getNiveau_Difficulte(); ?>" required />
                    </div>
                </div>
            </div>
            <div class="container mb-3">
                <div class="row">
                    <div class="col">
                        <button type="submit" class="btn btn-danger" name="submitedit">Modifier</button>
                    </div>
                </div>
            </div>
        </form>
    </div>








    <script>
        var counter = document.getElementById("ajouter").parentNode.childElementCount - 1;
        var counterIng = document.getElementById("ajouterING").parentNode.childElementCount - 1;

        function jqueryStuffAdd() {
            counter++;
            var div = document.createElement("div");
            div.innerHTML = "<div class='row mb-1' id='etape-id-" + counter + "'><div class='col'><textarea type='text' class='form-control' name='etape-" + counter + "' placeholder='Etape " + counter + "' required></textarea></div><div class='col-2'><button type='button' id='" + counter + "' onClick='jqueryStuffDelete(this.id)' class='btn btn-danger' name='supprimer'><i class='far fa-minus-square'></i></button></div></div>";
            document.getElementById("ajouter").parentNode.appendChild(div);
        }

        function jqueryStuffAddIngredient() {
            counterIng++;
            var div = document.createElement("div");
            div.innerHTML = "<div class='row mb-1' id='ingredient-id-" + counterIng + "'>  <div class='col-4'>    <input      type='text'      class='form-control'      name='ingredient-nom-" + counterIng + "'      placeholder='Nom Ingredient " + counterIng + "'      required    >  </div><div class='col'>    <input      type='number'      class='form-control'  max='1000' min='1'      name='ingredient-quantite-" + counterIng + "'      placeholder='Quatité'      required    >  </div><div class='col'>    <select  class='form-control'      name='ingredient-unite-" + counterIng + "' required    ><option value='kg'>kg</option><option value='g'>g</option><option value='litre'>litre</option><option value='ml'>millilitre</option><option value='cuillere'>cuillère</option><option value='unite'>unite</option></select>  </div>  <div class='col-2'>    <button      type='button'      id='" + counterIng + "'      onClick='jqueryStuffDeleteIng(this.id)'      class='btn btn-danger'      name='supprimer'    >      <i class='far fa-minus-square'></i>    </button>  </div></div>";
            document.getElementById("ajouterING").parentNode.appendChild(div);
        }

        function jqueryStuffDelete(id) {
            if (counter > 0) {
                document.getElementById("ajouter").parentNode.removeChild(document.getElementById("etape-id-" + id).parentNode);
                counter = document.getElementById("ajouter").parentNode.childElementCount - 1;
            }
        }

        function jqueryStuffDeleteIng(id) {
            if (counterIng > 0) {
                document.getElementById("ajouterING").parentNode.removeChild(document.getElementById("ingredient-id-" + id).parentNode);
                counterIng = document.getElementById("ajouterING").parentNode.childElementCount - 1;
            }
        }
    </script>
</body>

</html>